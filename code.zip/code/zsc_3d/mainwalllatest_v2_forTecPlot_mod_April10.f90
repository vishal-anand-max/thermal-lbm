!-------------------------------------------------------------------------------
! File     : Common
!-------------------------------------------------------------------------------
!> @file
!! Modules that contain common variables

!> @brief Definition of single and double data types
 MODULE NTypes
 IMPLICIT NONE
 SAVE

 INTEGER, PARAMETER :: SGL = KIND(1.0)
 INTEGER, PARAMETER :: DBL = KIND(1.D0)

 END MODULE NTypes

!> @brief Parameters related to the geometry and the time intervals
 MODULE Domain
 USE NTypes, ONLY : DBL
 IMPLICIT NONE
 SAVE

! Time step and limits
 INTEGER :: iStep, tCall, tDump, tStat, MaxStep

! Domain size
! (xmax, xmin) : computational domain size limits
! (xl  , xu  ) : local minimun and maximum values for x in a given processor
! (xlg , xug ) : local ghost node position (xlg = xl-1, xug = xu+1)
 INTEGER :: xjump, xo, yo, zo
 INTEGER :: now, nxt, NX, NY, NZ, NPX, NPy, NPZ
 INTEGER :: xmin, xmax, xl, xu, xlg, xug
 INTEGER :: ymin, ymax, yl, yu, ylg, yug
 INTEGER :: zmin, zmax, zl, zu, zlg, zug
 INTEGER :: xsize, xsize2, xsize3, xsize4, xsize5
 INTEGER :: ysize, ysize2, ysize3, ysize4, ysize5
 INTEGER :: zsize, zsize2, zsize3, zsize4, zsize5
 INTEGER :: xedge, yedge, zedge

! ndim = spatial dimension
 INTEGER, PARAMETER :: ndim = 3

! Array for neigbors
 INTEGER, ALLOCATABLE, DIMENSION(:,:,:,:) :: ni

! Inverse of the initial volume of the discrete phase 
 REAL(KIND = DBL) :: invInitVol

! Define constants used in the code (inv36 = 1/36, inv12 = 1/12, invPi = 1/pi)
 REAL(KIND = DBL), PARAMETER :: inv36  = 0.02777777777778D0
 REAL(KIND = DBL), PARAMETER :: inv12 = 0.08333333333333333333D0
 REAL(KIND = DBL), PARAMETER :: invPi = 0.31850988618379067154D0

 END MODULE Domain

!> @brief Parameters related to hydrodynamics quantities
 MODULE FluidParams
 USE NTypes, ONLY : DBL
 IMPLICIT NONE
 SAVE

 INTEGER :: nBubbles
 REAL(KIND = DBL), ALLOCATABLE, DIMENSION(:,:) :: bubbles
 REAL(KIND = DBL), DIMENSION(1:11) :: Convergence
 REAL(KIND = DBL) :: sigma, IntWidth, Gamma
 REAL(KIND = DBL) :: alpha, alpha4, kappa
 REAL(KIND = DBL) :: tauPhi, invTauPhi, invTauPhi1, phiStar, phiStar2, phiStar4
 REAL(KIND = DBL) :: rhoL, rhoH
 REAL(KIND = DBL) :: tauRho, invTauRho, invTauRhoOne, invTauRhoHalf
 REAL(KIND = DBL) :: eta, eta2, invEta2
 REAL(KIND = DBL) :: gravity, gravX, gravZ, Eo, eps, pConv
 REAL(KIND = DBL) :: sinthita, costhita

 REAL(KIND = DBL), ALLOCATABLE, DIMENSION(:,:,:) :: phi
 REAL(KIND = DBL), ALLOCATABLE, DIMENSION(:,:,:,:) :: u


 END MODULE FluidParams

!> @brief Parameters related to the LBM discretization
 MODULE LBMParams
 USE NTypes, ONLY : DBL
 IMPLICIT NONE
 SAVE

! fdim = order parameter dimension - 1 (D3Q7)
! gdim = momentum dimension - 1        (D3Q19)
 INTEGER, PARAMETER :: fdim = 6
 INTEGER, PARAMETER :: gdim = 18

! Distribution functions
 REAL(KIND = DBL), ALLOCATABLE, DIMENSION(:,:,:,:,:) :: f, g

! D3Q7/D3Q19 Lattice speed of sound (Cs = 1/DSQRT(3), Cs_sq = 1/3, invCs_sq = 3)
 REAL(KIND = DBL), PARAMETER :: Cs       = 0.57735026918962576451D0
 REAL(KIND = DBL), PARAMETER :: Cs_sq    = 0.33333333333333333333D0
 REAL(KIND = DBL), PARAMETER :: invCs_sq = 3.00000000000000000000D0

! Distributions weights (D3Q19: Eg0 = 1/3, Eg1 = 1/18, Eg2 = 1/36)
 REAL(KIND = DBL), PARAMETER :: Eg0 = 0.33333333333333333333D0
 REAL(KIND = DBL), PARAMETER :: Eg1 = 0.05555555555555555556D0
 REAL(KIND = DBL), PARAMETER :: Eg2 = 0.02777777777777777778D0

! Modified distribution weight (to avoid operations: EgiC = Egi*invCs_sq)
 REAL(KIND = DBL), PARAMETER :: Eg0C = 1.00000000000000000000D0
 REAL(KIND = DBL), PARAMETER :: Eg1C = 0.16666666666666666667D0
 REAL(KIND = DBL), PARAMETER :: Eg2C = 0.08333333333333333333D0
 REAL(KIND = DBL) :: w, Eg0n, Eg1n, Eg2n, EgC0n, EgC1n, EgC2n

 END MODULE LBMParams
!-------------------------------------------------------------------------------
! Program  : ZSC-3D-STD
!-------------------------------------------------------------------------------
!> @file
!! Driver for the parallel D3Q7/D3Q19 Zheng-Shu-Chew multiphase LBM
!> @details
!! Driver for the standard parallel implementation of the Zheng-Shu-Chew
!! multiphase LBM using D3Q7/D3Q19 discretization and periodic boundary
!! conditions, including the gravitational force. For details:
!!
!! Journal of Computational Physics 218: 353-371, 2006.
!!
!! Parallel Implementation using MPI. Convergence test and post-processing
!! functions designed for single drop/bubble cases.
!!
!! The average velocity, mass conservation factor, effective radius of the drop,
!! pressure difference between the inside and the outside of the drop and the
!! error with respect to the analytical value given by Laplace's equation are
!! written to file "stats.out"

 PROGRAM main

! Common Variables
 USE Domain,      ONLY : iStep, MaxStep, now, nxt, tDump, tStat
 USE FluidParams, ONLY : eps, pConv
 IMPLICIT NONE

! Read input parameters, broadcast, and create virtual CPU grid
 CALL Parameters


! Allocate memory for common arrays and initialize
 CALL MemAlloc(1)

 CALL Init


! Main Iteration Loop
 DO iStep = 1, Maxstep

   CALL Collision
 
   CALL Stream
   
   Print*,iStep,Maxstep

   now = 1 - now
   nxt = 1 - nxt

   IF( MOD(iStep,tStat) == 0 ) CALL Stats
   IF( MOD(iStep,tDump) == 0 ) CALL VtkDump
    IF( eps < pConv ) EXIT

 END DO

! Save final data
 
 CALL VtkDump

! Free memory, finalize MPI and end program
 CALL MemAlloc(2)
 

 END PROGRAM

!------------------------------------------------------------------------------------------------------------
!-------------------------------------------------------------------------------
! Subroutine : Parameters
!-------------------------------------------------------------------------------
!> @file
!! Read input parameters and define simulation constants
!> @details
!! Read input parameters from files "properties.in" and "discrete.in" and define
!! constants for the simulation in the parallel D3Q7/D3Q19 Zheng-Shu-Chew
!! multiphase LBM.
!!


 SUBROUTINE Parameters

! Common variables
 USE Domain
 USE FluidParams
 USE LBMParams
 IMPLICIT NONE

! Local variables
 INTEGER :: i, j, k
 INTEGER :: IO_ERR

! Read parameter data from file in master node

   OPEN(UNIT = 10, FILE = "properties.in", STATUS = "OLD", ACTION = "READ", &
        IOSTAT = IO_ERR)

     READ(10,*)
     READ(10,*) Maxstep
     READ(10,*)
     READ(10,*) tStat, tDump, xjump
     READ(10,*)
     READ(10,*) xmin, xmax, ymin, ymax, zmin, zmax
     READ(10,*)
     READ(10,*) rhoL, rhoH
     READ(10,*)
     READ(10,*) tauRho, tauPhi
     READ(10,*)
     READ(10,*) IntWidth, sigma, Gamma
     READ(10,*)
     READ(10,*) Eo, pConv
	 READ(10,*)
	 READ(10,*) sinthita, costhita


     CLOSE(UNIT = 10)


! Read bubble positions
   OPEN(UNIT = 10, FILE = "discrete.in", STATUS = "OLD", ACTION = "READ", &
      IOSTAT = IO_ERR)
   IF ( IO_ERR == 0 ) THEN
       READ(10,*)
       READ(10,*) nBubbles
       READ(10,*)
       ALLOCATE( bubbles(1:nBubbles,1:4) )
       
       DO i = 1, nBubbles
         READ(10,*) bubbles(i,1), bubbles(i,2), bubbles(i,3), bubbles(i,4)
       END DO
   
   CLOSE(UNIT=10)
   ELSE
     
     STOP "Error: Unable to open input file 'discrete.in'."
   END IF
  

! Fluid properties
 phiStar       = 0.5D0*(rhoH - rhoL)
 phiStar2      = phiStar*phiStar
 invTauRho     = 1.D0/tauRho
 invTauRhoOne  = 1.D0 - invTauRho
 invTauRhoHalf = 1.D0 - 0.5D0*invTauRho

 eta        = 1.D0/(tauPhi + 0.5D0)
 eta2       = 1.D0 - eta
 invEta2    = 0.5D0/eta
 invTauPhi  = 1.D0/tauPhi
 invTauPhi1 = 1.D0 - invTauPhi

! Chemical Potential Stuff
 alpha  = 0.75D0*sigma/(IntWidth*phistar**4.D0)
 alpha4 = alpha*4.D0
 kappa  = (IntWidth*phistar)**2.D0*alpha/2.D0

! Rc = bubbles(1,4) Use the first bubble as the largest in the system
 gravity = 0.25D0*Eo*sigma/( (rhoH - rhoL)*bubbles(1,4)*bubbles(1,4) )
 gravX = 2.D0*phiStar*gravity*costhita
 gravZ = 2.D0*phiStar*gravity*sinthita

! Modified LBM parameters
 Eg0n  = invTauRho*Eg0
 Eg1n  = invTauRho*Eg1
 Eg2n  = invTauRho*Eg2

 EgC0n = invTauRhoHalf*Eg0C
 EgC1n = invTauRhoHalf*Eg1C
 EgC2n = invTauRhoHalf*Eg2C

! Middle planes (x = xo), (y = yo), (z = zo)
 xo = INT(0.5D0*(xmax + xmin))
 yo = INT(0.5D0*(ymax + ymin))
 zo = INT(0.5D0*(zmax + zmin))

 RETURN
 END SUBROUTINE Parameters
!---------------------------------------------------------------------------------------------------------------
!-------------------------------------------------------------------------------
! Subroutine : MemAlloc
!-------------------------------------------------------------------------------
!> @file
!! Allocate (FLAG == 1) or deallocate (FLAG != 1) memory for common arrays.
!> @details
!! If FLAG is 1 then memory is allocated for the following common arrays:
!!
!! - \b phi (order parameter)
!! - \b ni  (near neighbors)
!! - \b f   (order parameter distribution function)
!! - \b g   (momentum distribution function)
!!
!! and the MPI buffer arrays required by the parallel D3Q7/D3Q19 Zheng-Shu-Chew
!! multiphase LBM. Memory is deallocated when FLAG is different from one.

 SUBROUTINE MemAlloc(FLAG)

!  Common Variables
 USE Domain
 USE FluidParams, ONLY : phi, u
 USE LBMParams,   ONLY : f, fdim, g, gdim
 IMPLICIT NONE

 !   Input/Output Parameters
 INTEGER, INTENT (IN) :: FLAG

 IF(FLAG == 1) THEN

! Near neighbors and order parameter arrays
 ALLOCATE(  ni(xmin-1:xmax+1,ymin-1:ymax+1,zmin-1:zmax+1,1:6) )
 ALLOCATE( phi(xmin-1:xmax+1,ymin-1:ymax+1,zmin-1:zmax+1) )
 ALLOCATE( u(xmin-1:xmax+1,ymin-1:ymax+1,zmin-1:zmax+1,3) )


! Distribution function arrays
 ALLOCATE( f(xmin-1:xmax+1,ymin-1:ymax+1,zmin-1:zmax+1,0:fdim,0:1) )
 ALLOCATE( g(xmin-1:xmax+1,ymin-1:ymax+1,zmin-1:zmax+1,0:gdim,0:1) )
 

 !ALLOCATE( c1(xmax-50+1:xmax,ymin-1:ymax+1))
 !ALLOCATE( c2(xmax-50+1:xmax,ymin-1:ymax+1))


 ELSE
   DEALLOCATE( ni )
   DEALLOCATE( phi )
   DEALLOCATE( f )
   DEALLOCATE( g )
   DEALLOCATE( u )
  ! DEALLOCATE( c1 )
   !DEALLOCATE( c2 )


 END IF

 RETURN
 END SUBROUTINE MemAlloc
!--------------------------------------------------------------------------------------------------------
!-------------------------------------------------------------------------------
! Subroutine : Init
!-------------------------------------------------------------------------------
!> @file
!! Initialize all variables and arrays and save initialized data to file.
!> @details
!! Initialization step for the parallel D3Q7/D3Q19 Zheng-Shu-Chew multiphase LBM.
!! Smeared interface initialized using equilibrium order parameter function for
!! each drop defined in the input (in the range [R-IntWidth,R+IntWidth]). The
!! distribution functions f and g are initialized to their equilibrium values
!! for zero velocity.

 SUBROUTINE Init

!  Common Variables
 USE NTypes,    ONLY : DBL
 USE Domain
 USE FluidParams
 USE LBMParams
 IMPLICIT NONE

!  Local Variables
 INTEGER :: count, i, j, k, m, ie, iw, jn, js, kt, kb
 REAL(KIND = DBL) :: r, Af0, Ag0, Af1, Ag1, Ag2
 REAL(KIND = DBL) :: c(0:18)
 REAL(KIND = DBL) :: muPhin, phin, rhon
 REAL(KIND = DBL) :: lapPhi
 REAL(KIND = DBL) :: c1 (75,75,18),C2(75,75,6)

 
 integer, parameter:: opposite(0:18) = (/0,2,1,4,3,6,5,8,7,10,9,12,11,14,13,16,15,18,17/)


! Initialize counters
 iStep = 0
 tCall = 1
 now   = 0
 nxt   = 1
 eps   = 1.D0

! Set vtk limits
 NX = xmax - xmin + 1
 NY = ymax - ymin + 1
 NZ = zmax - zmin + 1
 NPZ = 0
 NPY = 0
 NPX = 0
 DO k = zmin, zmax, xjump
   NPZ = NPZ + 1
 END DO
 DO j = ymin, ymax, xjump
   NPY = NPY + 1
 END DO
 DO i = xmin, xmax, xjump
   NPX = NPX + 1
 END DO

!--------- Set near neighbors and order parameter ------------------------------
 DO k = zmin, zmax 
   DO j = ymin, ymax
     DO i = xmin, xmax

       phi(i,j,k) = -phistar
       DO m = 1, nBubbles

         R =  DSQRT( ( DBLE(i) - bubbles(m,1) )**2 &
           + ( DBLE(j) - bubbles(m,2) )**2 + ( DBLE(k) - bubbles(m,3) )**2 )

         IF ( R <= ( DBLE(bubbles(m,4)) + IntWidth ) ) THEN
           phi(i,j,k) = phistar*TANH( 2.D0*( DBLE(bubbles(m,4)) - R )/IntWidth )
         END IF
       END DO

! Assign neighbor values to array
         ni(i,j,k,1) = i + 1
         ni(i,j,k,2) = i - 1
         ni(i,j,k,3) = j + 1
         ni(i,j,k,4) = j - 1
         ni(i,j,k,5) = k + 1
         ni(i,j,k,6) = k - 1

     END DO
   END DO
 END DO
 



!Correct near neighbours at domain edges (periodic boundary conditions)
 !ni(xmin,:,:,2) = xmax
 !ni(xmax,:,:,1) = xmin
 !ni(:,ymin,:,4) = ymax
 !ni(:,ymax,:,3) = ymin
 !ni(:,:,zmin,6) = zmax
 !ni(:,:,zmax,5) = zmin
!Correct near neighbours at domain edges (wall boundary conditions)
! ni(xmin,:,:,2) = ni(xmin,:,:,1)
! ni(xmax,:,:,1) = ni(xmax,:,:,2)
! ni(:,ymin,:,4) = ni(:,ymin,:,3)
! ni(:,ymax,:,3) = ni(:,ymax,:,4)



!--------- Initialize distribution functions -----------------------------------
 DO k = zmin, zmax 
   DO j = ymin, ymax
     DO i = xmin, xmax

! Assign the neighbours
       ie = ni(i,j,k,1)
       iw = ni(i,j,k,2)
       jn = ni(i,j,k,3)
       js = ni(i,j,k,4)
       kt = ni(i,j,k,5)
       kb = ni(i,j,k,6)
!print*,'hi',i,j,k,xmax,ymax,zmax
!print*,'hi',ie,iw,jn,js,kt,kb
! Laplacian of the order parameter
       lapphi = ( phi(ie,jn,k) + phi(iw,js,k) + phi(ie,js,k) + phi(iw,jn,k) &
              +   phi(ie,j,kt) + phi(iw,j,kb) + phi(ie,j,kb) + phi(iw,j,kt) &
              +   phi(i,jn,kt) + phi(i,js,kb) + phi(i,jn,kb) + phi(i,js,kt) &
              +   2.0D0*( phi(ie,j,k) + phi(iw,j,k) + phi(i,jn,k)           &
              +   phi(i,js,k) + phi(i,j,kt) + phi(i,j,kb) - 12.d0*phi(i,j,k) ) )*inv36

!  Chemical potential
       phin   = phi(i,j,k)
       rhon   = 0.5D0*(rhoH + rhoL)
       muPhin = alpha4*phin*(phin*phin - phiStar*phiStar) - kappa*lapPhi

! Set distribution function f to its equilibrium value
       Af0 = -3.D0*Gamma*muPhin
       Af1 = 0.5D0*Gamma*muPhin
       f(i,j,k,0,now)   = Af0 + phin
       f(i,j,k,1:6,now) = Af1


! Set distribution functiong to its equilibrium value
       Ag0 = Eg0*(rhon - 6.D0*phin*muphin)
       Ag1 = Eg1*(3.D0*phin*muphin + rhon)
       Ag2 = Eg2*(3.D0*phin*muphin + rhon)
       g(i,j,k,0,now)    = Ag0
       g(i,j,k,1:6,now)  = Ag1
       g(i,j,k,7:18,now) = Ag2

     END DO
   END DO
 END DO

 
 
 !For Wall B.C. up to zmax
	DO i = xmin, xmax 
	   DO j = ymin, ymax
		 DO k = zmin, zmax
		 
		 if (i.eq.xmin)then
		 
			g(i,j,k,1,now)=g(i,j,k,2,now)
			g(i,j,k,3,now)=g(i,j,k,4,now)
			g(i,j,k,5,now)=g(i,j,k,6,now)
			g(i,j,k,7,now)=g(i,j,k,8,now)
			g(i,j,k,9,now)=g(i,j,k,10,now)
			g(i,j,k,11,now)=g(i,j,k,12,now)
			g(i,j,k,13,now)=g(i,j,k,14,now)
			g(i,j,k,15,now)=g(i,j,k,16,now)
			g(i,j,k,17,now)=g(i,j,k,18,now)

			g(i,j,k,2,now)=g(i,j,k,1,now)
			g(i,j,k,4,now)=g(i,j,k,3,now)
			g(i,j,k,6,now)=g(i,j,k,5,now)
			g(i,j,k,8,now)=g(i,j,k,7,now)
			g(i,j,k,10,now)=g(i,j,k,9,now)
			g(i,j,k,12,now)=g(i,j,k,11,now)
			g(i,j,k,14,now)=g(i,j,k,13,now)
			g(i,j,k,16,now)=g(i,j,k,15,now)
			g(i,j,k,18,now)=g(i,j,k,17,now)
			
			f(i,j,k,1,now)=f(i,j,k,2,now)
			f(i,j,k,3,now)=f(i,j,k,4,now)
			f(i,j,k,5,now)=f(i,j,k,6,now)
			
			f(i,j,k,2,now)=f(i,j,k,1,now)
			f(i,j,k,4,now)=f(i,j,k,3,now)
			f(i,j,k,6,now)=f(i,j,k,5,now)

		elseif (i.eq.xmax)then

			g(i,j,k,2,now)=g(i,j,k,1,now)
			g(i,j,k,4,now)=g(i,j,k,3,now)
			g(i,j,k,6,now)=g(i,j,k,5,now)
			g(i,j,k,8,now)=g(i,j,k,7,now)
			g(i,j,k,10,now)=g(i,j,k,9,now)
			g(i,j,k,12,now)=g(i,j,k,11,now)
			g(i,j,k,14,now)=g(i,j,k,13,now)
			g(i,j,k,16,now)=g(i,j,k,15,now)
			g(i,j,k,18,now)=g(i,j,k,17,now)

			g(i,j,k,1,now)=g(i,j,k,2,now)
			g(i,j,k,3,now)=g(i,j,k,4,now)
			g(i,j,k,5,now)=g(i,j,k,6,now)
			g(i,j,k,7,now)=g(i,j,k,8,now)
			g(i,j,k,9,now)=g(i,j,k,10,now)
			g(i,j,k,11,now)=g(i,j,k,12,now)
			g(i,j,k,13,now)=g(i,j,k,14,now)
			g(i,j,k,15,now)=g(i,j,k,16,now)
			g(i,j,k,17,now)=g(i,j,k,18,now)
			
			f(i,j,k,2,now)=f(i,j,k,1,now)
			f(i,j,k,4,now)=f(i,j,k,3,now)
			f(i,j,k,6,now)=f(i,j,k,5,now)

			f(i,j,k,1,now)=f(i,j,k,2,now)
			f(i,j,k,3,now)=f(i,j,k,4,now)
			f(i,j,k,5,now)=f(i,j,k,6,now)
		
		elseif (j.eq.ymin)then
			
			g(i,j,k,2,now)=g(i,j,k,1,now)
			g(i,j,k,3,now)=g(i,j,k,4,now)
			g(i,j,k,6,now)=g(i,j,k,5,now)
			g(i,j,k,7,now)=g(i,j,k,8,now)
			g(i,j,k,10,now)=g(i,j,k,9,now)
			g(i,j,k,12,now)=g(i,j,k,11,now)
			g(i,j,k,14,now)=g(i,j,k,13,now)
			g(i,j,k,15,now)=g(i,j,k,16,now)
			g(i,j,k,17,now)=g(i,j,k,18,now)

			g(i,j,k,1,now)=g(i,j,k,2,now)
			g(i,j,k,4,now)=g(i,j,k,3,now)
			g(i,j,k,5,now)=g(i,j,k,6,now)
			g(i,j,k,8,now)=g(i,j,k,7,now)
			g(i,j,k,9,now)=g(i,j,k,10,now)
			g(i,j,k,11,now)=g(i,j,k,12,now)
			g(i,j,k,13,now)=g(i,j,k,14,now)
			g(i,j,k,16,now)=g(i,j,k,15,now)
			g(i,j,k,18,now)=g(i,j,k,17,now)
			
			f(i,j,k,2,now)=f(i,j,k,1,now)
			f(i,j,k,3,now)=f(i,j,k,4,now)
			f(i,j,k,6,now)=f(i,j,k,5,now)

			f(i,j,k,1,now)=f(i,j,k,2,now)
			f(i,j,k,4,now)=f(i,j,k,3,now)
			f(i,j,k,5,now)=f(i,j,k,6,now)

		elseif (j.eq.ymax)then

			g(i,j,k,1,now)=g(i,j,k,2,now)
			g(i,j,k,4,now)=g(i,j,k,3,now)
			g(i,j,k,5,now)=g(i,j,k,6,now)
			g(i,j,k,8,now)=g(i,j,k,7,now)
			g(i,j,k,9,now)=g(i,j,k,10,now)
			g(i,j,k,11,now)=g(i,j,k,12,now)
			g(i,j,k,13,now)=g(i,j,k,14,now)
			g(i,j,k,16,now)=g(i,j,k,15,now)
			g(i,j,k,18,now)=g(i,j,k,17,now)

			g(i,j,k,2,now)=g(i,j,k,1,now)
			g(i,j,k,3,now)=g(i,j,k,4,now)
			g(i,j,k,6,now)=g(i,j,k,5,now)
			g(i,j,k,7,now)=g(i,j,k,8,now)
			g(i,j,k,10,now)=g(i,j,k,9,now)
			g(i,j,k,12,now)=g(i,j,k,11,now)
			g(i,j,k,14,now)=g(i,j,k,13,now)
			g(i,j,k,15,now)=g(i,j,k,16,now)
			g(i,j,k,17,now)=g(i,j,k,18,now)
			
			f(i,j,k,1,now)=f(i,j,k,2,now)
			f(i,j,k,4,now)=f(i,j,k,3,now)
			f(i,j,k,5,now)=f(i,j,k,6,now)

			f(i,j,k,2,now)=f(i,j,k,1,now)
			f(i,j,k,3,now)=f(i,j,k,4,now)
			f(i,j,k,6,now)=f(i,j,k,5,now)

			else

			continue

			endif
 
         END DO
	   END DO
	END DO

!For Wall B.C. up to zmax -50 at xmax -50 and xmin +50
	DO i = xmin, xmax 
	   DO j = ymin, ymax
		 DO k = zmin, zmax - 50
		 
		 if (i.eq. (xmax - 50))then
		 
			g(i,j,k,1,now)=g(i,j,k,2,now)
			g(i,j,k,3,now)=g(i,j,k,4,now)
			g(i,j,k,5,now)=g(i,j,k,6,now)
			g(i,j,k,7,now)=g(i,j,k,8,now)
			g(i,j,k,9,now)=g(i,j,k,10,now)
			g(i,j,k,11,now)=g(i,j,k,12,now)
			g(i,j,k,13,now)=g(i,j,k,14,now)
			g(i,j,k,15,now)=g(i,j,k,16,now)
			g(i,j,k,17,now)=g(i,j,k,18,now)

			g(i,j,k,2,now)=g(i,j,k,1,now)
			g(i,j,k,4,now)=g(i,j,k,3,now)
			g(i,j,k,6,now)=g(i,j,k,5,now)
			g(i,j,k,8,now)=g(i,j,k,7,now)
			g(i,j,k,10,now)=g(i,j,k,9,now)
			g(i,j,k,12,now)=g(i,j,k,11,now)
			g(i,j,k,14,now)=g(i,j,k,13,now)
			g(i,j,k,16,now)=g(i,j,k,15,now)
			g(i,j,k,18,now)=g(i,j,k,17,now)
			
			f(i,j,k,1,now)=f(i,j,k,2,now)
			f(i,j,k,3,now)=f(i,j,k,4,now)
			f(i,j,k,5,now)=f(i,j,k,6,now)
			
			f(i,j,k,2,now)=f(i,j,k,1,now)
			f(i,j,k,4,now)=f(i,j,k,3,now)
			f(i,j,k,6,now)=f(i,j,k,5,now)

		elseif (i.eq.(xmin + 50))then

			g(i,j,k,2,now)=g(i,j,k,1,now)
			g(i,j,k,4,now)=g(i,j,k,3,now)
			g(i,j,k,6,now)=g(i,j,k,5,now)
			g(i,j,k,8,now)=g(i,j,k,7,now)
			g(i,j,k,10,now)=g(i,j,k,9,now)
			g(i,j,k,12,now)=g(i,j,k,11,now)
			g(i,j,k,14,now)=g(i,j,k,13,now)
			g(i,j,k,16,now)=g(i,j,k,15,now)
			g(i,j,k,18,now)=g(i,j,k,17,now)

			g(i,j,k,1,now)=g(i,j,k,2,now)
			g(i,j,k,3,now)=g(i,j,k,4,now)
			g(i,j,k,5,now)=g(i,j,k,6,now)
			g(i,j,k,7,now)=g(i,j,k,8,now)
			g(i,j,k,9,now)=g(i,j,k,10,now)
			g(i,j,k,11,now)=g(i,j,k,12,now)
			g(i,j,k,13,now)=g(i,j,k,14,now)
			g(i,j,k,15,now)=g(i,j,k,16,now)
			g(i,j,k,17,now)=g(i,j,k,18,now)
			
			f(i,j,k,2,now)=f(i,j,k,1,now)
			f(i,j,k,4,now)=f(i,j,k,3,now)
			f(i,j,k,6,now)=f(i,j,k,5,now)

			f(i,j,k,1,now)=f(i,j,k,2,now)
			f(i,j,k,3,now)=f(i,j,k,4,now)
			f(i,j,k,5,now)=f(i,j,k,6,now)
		
		
			else

			continue

			endif
 
         END DO
	   END DO
	END DO

	

! B.C. for Zmin 	
	DO i = xmin+50, xmax-50
       DO j = ymin, ymax
	   
			g(i,j,zmin,1,now)=g(i,j,zmin,2,now)
			g(i,j,zmin,3,now)=g(i,j,zmin,4,now)
			g(i,j,zmin,5,now)=g(i,j,zmin,6,now)
			g(i,j,zmin,7,now)=g(i,j,zmin,8,now)
			g(i,j,zmin,9,now)=g(i,j,zmin,10,now)
			g(i,j,zmin,11,now)=g(i,j,zmin,12,now)
			g(i,j,zmin,14,now)=g(i,j,zmin,13,now)
			g(i,j,zmin,15,now)=g(i,j,zmin,16,now)
			g(i,j,zmin,18,now)=g(i,j,zmin,17,now)
			
			g(i,j,zmin,2,now)=g(i,j,zmin,1,now)
			g(i,j,zmin,4,now)=g(i,j,zmin,3,now)
			g(i,j,zmin,6,now)=g(i,j,zmin,5,now)
			g(i,j,zmin,8,now)=g(i,j,zmin,7,now)
			g(i,j,zmin,10,now)=g(i,j,zmin,9,now)
			g(i,j,zmin,12,now)=g(i,j,zmin,11,now)
			g(i,j,zmin,13,now)=g(i,j,zmin,14,now)
			g(i,j,zmin,16,now)=g(i,j,zmin,15,now)
			g(i,j,zmin,17,now)=g(i,j,zmin,18,now)
			
			f(i,j,zmin,1,now)=f(i,j,zmin,2,now)
			f(i,j,zmin,3,now)=f(i,j,zmin,4,now)
			f(i,j,zmin,5,now)=f(i,j,zmin,6,now)
			
			f(i,j,zmin,2,now)=f(i,j,zmin,1,now)
			f(i,j,zmin,4,now)=f(i,j,zmin,3,now)
			f(i,j,zmin,6,now)=f(i,j,zmin,5,now)
			
		END DO
	END DO

	! B.C. for Zmin 	
	DO i = xmin, xmin +50
       DO j = ymin, ymax
	        c1(i,j,2)=g(xmax -50+i,j,zmin,2,nxt)
			!g(xmax -50+i,j,zmin,2,nxt)=g(i,j,zmin,1,nxt)
		
            c1(i,j,4)=g(xmax -50+i,j,zmin,4,nxt)
			!g(xmax -50+i,j,zmin,4,nxt)=g(i,j,zmin,3,nxt)
			
			c1(i,j,6)=g(xmax -50+i,j,zmin,6,nxt)
			!g(xmax -50+i,j,zmin,6,nxt)=g(i,j,zmin,5,nxt)
			
			c1(i,j,8)=g(xmax -50+i,j,zmin,8,nxt)
			!g(xmax -50+i,j,zmin,8,nxt)=g(i,j,zmin,7,nxt)
			
			c1(i,j,10)=g(xmax -50+i,j,zmin,10,nxt)
			!g(xmax -50+i,j,zmin,10,nxt)=g(i,j,zmin,9,nxt)
			
			c1(i,j,12)=g(xmax -50+i,j,zmin,12,nxt)
			!g(xmax -50+i,j,zmin,12,nxt)=g(i,j,zmin,11,nxt)
			
			c1(i,j,13)=g(xmax -50+i,j,zmin,13,nxt)
            !g(xmax -50+i,j,zmin,13,nxt)=g(i,j,zmin,14,nxt)
	    
			c1(i,j,16)=g(xmax -50+i,j,zmin,16,nxt)
			!g(xmax -50+i,j,zmin,16,nxt)=g(i,j,zmin,15,nxt)
			
            c1(i,j,17)=g(xmax -50+i,j,zmin,17,nxt)
		!g(xmax -50+i,j,zmin,17,nxt)=g(i,j,zmin,18,nxt)
			
			
			
			c1(i,j,1)=g(xmax -50+i,j,zmin,1,nxt)
			!g(xmax -50+i,j,zmin,1,nxt)=g(i,j,zmin,2,nxt)
		
            c1(i,j,3)=g(xmax -50+i,j,zmin,3,nxt)
			!g(xmax -50+i,j,zmin,3,nxt)=g(i,j,zmin,4,nxt)
			
			c1(i,j,5)=g(xmax -50+i,j,zmin,5,nxt)
			g(xmax -50+i,j,zmin,5,nxt)=g(i,j,zmin,6,nxt)
			
            c1(i,j,7)=g(xmax -50+i,j,zmin,7,nxt)
			!g(xmax -50+i,j,zmin,7,nxt)=g(i,j,zmin,8,nxt)
			
            c1(i,j,9)=g(xmax -50+i,j,zmin,9,nxt)
			!g(xmax -50+i,j,zmin,9,nxt)=g(i,j,zmin,10,nxt)
			

			c1(i,j,11)=g(xmax -50+i,j,zmin,11,nxt)
			g(xmax -50+i,j,zmin,11,nxt)=g(i,j,zmin,12,nxt)
			

			c1(i,j,14)=g(xmax -50+i,j,zmin,14,nxt)
			g(xmax -50+i,j,zmin,14,nxt)=g(i,j,zmin,13,nxt)
			

			c1(i,j,15)=g(xmax -50+i,j,zmin,15,nxt)
			g(xmax -50+i,j,zmin,15,nxt)=g(i,j,zmin,16,nxt)
			

			c1(i,j,18)=g(xmax -50+i,j,zmin,18,nxt)
			g(xmax -50+i,j,zmin,18,nxt)=g(i,j,zmin,17,nxt)
			

			
			c2(i,j,2)=f(xmax -50+i,j,zmin,2,nxt)
			!f(xmax -50+i,j,zmin,2,nxt)=f(i,j,zmin,1,nxt)
			

			c2(i,j,4)=f(xmax -50+i,j,zmin,4,nxt)
			!f(xmax -50+i,j,zmin,4,nxt)=f(i,j,zmin,3,nxt)
			

			c2(i,j,6)=f(xmax -50+i,j,zmin,6,nxt)
			f(xmax -50+i,j,zmin,5,nxt)=f(i,j,zmin,6,nxt)
			


			
			c2(i,j,1)=f(xmax -50+i,j,zmin,1,nxt)
			!f(xmax -50+i,j,zmin,1,nxt)=f(i,j,zmin,2,nxt)
			

			c2(i,j,3)=f(xmax -50+i,j,zmin,3,nxt)
			!f(xmax -50+i,j,zmin,3,nxt)=f(i,j,zmin,4,nxt)
			

			c2(i,j,5)=f(xmax -50+i,j,zmin,5,nxt)
			f(i,j,zmin,5,nxt)=f(xmax-50+i,j,zmin,6,nxt)
			
			
		END DO
	END DO

	! B.C. for Zmin 	
	DO i = xmin, xmin +50
       DO j = ymin, ymax
	   
           ! g(i,j,zmin,2,nxt)=c1(i,j,1)
			!g(i,j,zmin,1,nxt)=c1(i,j,2)
            
			!g(i,j,zmin,4,nxt)=c1(i,j,3)
			!g(i,j,zmin,3,nxt)=c1(i,j,4)

            !g(i,j,zmin,6,nxt)=c1(i,j,5)
		g(i,j,zmin,5,nxt)=c1(i,j,6)
         
           ! g(i,j,zmin,8,nxt)=c1(i,j,7)
		!g(i,j,zmin,7,nxt)=c1(i,j,8)

            !g(i,j,zmin,10,nxt)=c1(i,j,9)
		!g(i,j,zmin,9,nxt)=c1(i,j,10)

		!g(i,j,zmin,12,nxt)=c1(i,j,11)
			g(i,j,zmin,11,nxt)=c1(i,j,12)

            !g(i,j,zmin,13,nxt)=c1(i,j,14)
			g(i,j,zmin,14,nxt)=c1(i,j,13)

            !g(i,j,zmin,16,nxt)=c1(i,j,15)
			g(i,j,zmin,15,nxt)=c1(i,j,16)

            !g(i,j,zmin,17,nxt)=c1(i,j,18)
			g(i,j,zmin,18,nxt)=c1(i,j,17)
			


           

           
            !f(i,j,zmin,2,nxt)=c2(i,j,1)
			!f(i,j,zmin,1,nxt)=c2(i,j,2)

            !f(i,j,zmin,4,nxt)=c2(i,j,3)
			!f(i,j,zmin,3,nxt)=c2(i,j,4)

            !f(i,j,zmin,6,nxt)=c2(i,j,5)
			!f(i,j,zmin,5,nxt)=c2(i,j,6)


            
		END DO
	END DO

	! B.C. for Zmax - 50	
	DO i = xmin +50, xmax -50
       DO j = ymin, ymax
	   
			g(i,j,zmax -50,1,now)=g(i,j,zmax -50,2,now)
			g(i,j,zmax -50,3,now)=g(i,j,zmax -50,4,now)
			g(i,j,zmax -50,5,now)=g(i,j,zmax -50,6,now)
			g(i,j,zmax -50,7,now)=g(i,j,zmax -50,8,now)
			g(i,j,zmax -50,9,now)=g(i,j,zmax -50,10,now)
			g(i,j,zmax -50,11,now)=g(i,j,zmax -50,12,now)
			g(i,j,zmax -50,14,now)=g(i,j,zmax -50,13,now)
			g(i,j,zmax -50,15,now)=g(i,j,zmax -50,16,now)
			g(i,j,zmax -50,18,now)=g(i,j,zmax -50,17,now)
			
			g(i,j,zmax -50,2,now)=g(i,j,zmax -50,1,now)
			g(i,j,zmax -50,4,now)=g(i,j,zmax -50,3,now)
			g(i,j,zmax -50,6,now)=g(i,j,zmax -50,5,now)
			g(i,j,zmax -50,8,now)=g(i,j,zmax -50,7,now)
			g(i,j,zmax -50,10,now)=g(i,j,zmax -50,9,now)
			g(i,j,zmax -50,12,now)=g(i,j,zmax -50,11,now)
			g(i,j,zmax -50,13,now)=g(i,j,zmax -50,14,now)
			g(i,j,zmax -50,16,now)=g(i,j,zmax -50,15,now)
			g(i,j,zmax -50,17,now)=g(i,j,zmax -50,18,now)
			
			f(i,j,zmax -50,1,now)=f(i,j,zmax -50,2,now)
			f(i,j,zmax -50,3,now)=f(i,j,zmax -50,4,now)
			f(i,j,zmax -50,5,now)=f(i,j,zmax -50,6,now)
			
			f(i,j,zmax -50,2,now)=f(i,j,zmax -50,1,now)
			f(i,j,zmax -50,4,now)=f(i,j,zmax -50,3,now)
			f(i,j,zmax -50,6,now)=f(i,j,zmax -50,5,now)
			
		END DO
	END DO
	

! B.C. for Zmax 
    DO i = xmin, xmax
       DO j = ymin, ymax
	   
			g(i,j,zmax,2,now)=g(i,j,zmax,1,now)
			g(i,j,zmax,4,now)=g(i,j,zmax,3,now)
			g(i,j,zmax,6,now)=g(i,j,zmax,5,now)
			g(i,j,zmax,8,now)=g(i,j,zmax,7,now)
			g(i,j,zmax,10,now)=g(i,j,zmax,9,now)
			g(i,j,zmax,12,now)=g(i,j,zmax,11,now)
			g(i,j,zmax,13,now)=g(i,j,zmax,14,now)
			g(i,j,zmax,16,now)=g(i,j,zmax,15,now)
			g(i,j,zmax,17,now)=g(i,j,zmax,18,now)

			g(i,j,zmax,1,now)=g(i,j,zmax,2,now)
			g(i,j,zmax,3,now)=g(i,j,zmax,4,now)
			g(i,j,zmax,5,now)=g(i,j,zmax,6,now)
			g(i,j,zmax,7,now)=g(i,j,zmax,8,now)
			g(i,j,zmax,9,now)=g(i,j,zmax,10,now)
			g(i,j,zmax,11,now)=g(i,j,zmax,12,now)
			g(i,j,zmax,14,now)=g(i,j,zmax,13,now)
			g(i,j,zmax,15,now)=g(i,j,zmax,16,now)
			g(i,j,zmax,18,now)=g(i,j,zmax,17,now)
			
			f(i,j,zmax,2,now)=f(i,j,zmax,1,now)
			f(i,j,zmax,4,now)=f(i,j,zmax,3,now)
			f(i,j,zmax,6,now)=f(i,j,zmax,5,now)
			
			f(i,j,zmax,1,now)=f(i,j,zmax,2,now)
			f(i,j,zmax,3,now)=f(i,j,zmax,4,now)
			f(i,j,zmax,5,now)=f(i,j,zmax,6,now)
			
		END DO
	END DO

	DO k= zmin , zmax-50 
	DO j= ymin , ymax
    DO i= xmin , xmin+50


	u(i,j,k,1:3)= 0.0D0
	u(i,j,k,3)= 0.5D0 * ((abs(1 - dble(i-1) / (dble(xmin + 50-1) * 0.5D0)))**2 - 1.0D0) * ((abs(1 - dble(j-1) / (dble(ymax - 1) &
	* 0.5D0)))**2 - 1.0D0)
END DO
END DO
END DO


	DO k= zmin+100 , zmax 
	DO j= ymin , ymax
    DO i= xmin , xmax


	u(i,j,k,1:3)= 0.0D0
	u(i,j,k,1)= 0.5D0 * ((abs(1 - dble(k-1) / (dble(zmax-50-1) * 0.5D0)))**2 - 1.0D0) * ((abs(1 - dble(j-1) / (dble(ymax - 1) * 0.5D0 &
	)))**2 - 1.0D0)
END DO
END DO
END DO

	DO k= zmin , zmax 
	DO j= ymin , ymax
    DO i= xmin+150 , xmax


	u(i,j,k,1:3)= 0.0D0
	u(i,j,k,3)= -0.5D0 * ((abs(1 - dble(i-1) / (dble(xmin + 50-1) * 0.5D0)))**2 - 1.0D0) * ((abs(1 - dble(j-1) / (dble(ymax - 1)& 
	* 0.5D0)))**2 - 1.0D0)
END DO
END DO
END DO

 CALL Stats
 CALL VtkDump

 RETURN
 END SUBROUTINE Init
!--------------------------------------------------------------------------------------------------------------------
!-------------------------------------------------------------------------------
! Subroutine : Stats
!-------------------------------------------------------------------------------
!> @file
!! Calculate intermediate simulation results and save to file 'stats.out'
!> @details
!! Calculate average velocity, mass conservation factor and effective radius of
!! the drop, and write them to file "stats.out" for the parallel D2Q5/D2Q9
!! Zheng-Shu-Chew multiphase LBM.
!!
!! The effective radius is calculated assuming the drop is a perfect circle with
!! area given by Vol = (4/3)*Pi*R*R*R.
!!
!! Parallel implementation using MPI. Variables with the "Local" ending refer to
!! quantities calculated locally in the current processor, vproc. Variables with
!! the ending "Global" refer to qunatities calculated on the complete domain.
!! The parameters stored in the MPI excahnge buffers are defined below.
!!
!! @param data(1) : Volume
!! @param data(2) : Ux
!! @param data(3) : Uy
!! @param data(4) : Uz

 SUBROUTINE Stats

! Common Variables
 USE NTypes,      ONLY : DBL
 USE Domain,      ONLY : invInitVol, invPi, iStep, now, xmin, xmax, ymin, ymax, zmin, zmax
 USE FluidParams, ONLY : phi
 USE LBMParams,   ONLY : g
 IMPLICIT NONE

!  Local Variables
 INTEGER :: i, j, k
 INTEGER :: IO_ERR
 REAL(KIND = DBL) :: ux, uy, uz, rhon, invRhon
 REAL(KIND = DBL) :: invVol, Ref, Vef, Vol
 REAL(KIND = DBL), DIMENSION(1:4) :: dataLocal, dataGlobal

! Initialize
 dataLocal(:)  = 0.D0
 dataGlobal(:) = 0.D0

! Loop through all nodes inside the drop for the current processor, vproc
 DO k = zmin, zmax
   DO j = ymin, ymax
     DO i = xmin, xmax

       rhon    = SUM( g(i,j,k,:,now) )
       invRhon = 1.D0/rhon

! Calculate the velocity
       ux = ( g(i,j,k, 1,now) - g(i,j,k, 2,now) + g(i,j,k, 7,now) &
          -   g(i,j,k, 8,now) + g(i,j,k, 9,now) - g(i,j,k,10,now) &
          +   g(i,j,k,11,now) - g(i,j,k,12,now) + g(i,j,k,13,now) &
          -   g(i,j,k,14,now) )*invRhon

       uy = ( g(i,j,k, 3,now) - g(i,j,k, 4,now) + g(i,j,k, 7,now) &
          -   g(i,j,k, 8,now) - g(i,j,k, 9,now) + g(i,j,k,10,now) &
          +   g(i,j,k,15,now) - g(i,j,k,16,now) + g(i,j,k,17,now) &
          -   g(i,j,k,18,now) )*invRhon

       uz = ( g(i,j,k, 5,now) - g(i,j,k, 6,now) + g(i,j,k,11,now) &
          -   g(i,j,k,12,now) - g(i,j,k,13,now) + g(i,j,k,14,now) &
          +   g(i,j,k,15,now) - g(i,j,k,16,now) - g(i,j,k,17,now) &
          +   g(i,j,k,18,now) )*invRhon

! Calculate the accumulated quantities
       IF ( phi(i,j,k) >= 0.D0 ) THEN
         dataLocal(1) = dataLocal(1) + 1.D0
         dataLocal(2) = dataLocal(2) + ux
         dataLocal(3) = dataLocal(3) + uy
         dataLocal(4) = dataLocal(4) + uz
       END IF

     END DO
   END DO
 END DO
 
 

 Vol    = dataGlobal(1)
 invVol = 1.D0/Vol

! Define average velocity of the drop and effective radius and volume
 ux  = dataGlobal(2)*invVol
 uy  = dataGlobal(3)*invVol
 uz  = dataGlobal(4)*invVol
 Ref = ( Vol*invPi*0.75D0 )**(1.D0/3.D0)
 Vef = Vol*invInitVol

! Save velocity and effective radius and volume data from the master node only
 
   OPEN(UNIT = 10, FILE = "stats.out", STATUS = "UNKNOWN", POSITION = "APPEND",&
        IOSTAT = IO_ERR)
   IF ( IO_ERR == 0 ) THEN
     WRITE(10,'(I9,7ES19.9)')iStep,ux,uy,uz,Vef,Ref
     CLOSE(UNIT = 10)
   ELSE
     CALL MemAlloc(2)
     STOP "Error: Unable to open output file 'stats.out'."
   END IF


 RETURN
 END SUBROUTINE Stats
!------------------------------------------------------------------------------------------------------------
!-------------------------------------------------------------------------------
! Subroutine : VtkDump
!-------------------------------------------------------------------------------
!> @file
!! Save simulation data in VTK format
!> @details
!! Save order parameter, pressure, and velocity data in VTK format for the
!! parallel D3Q7/D3Q19 Zheng-Shu-Chew multiphase LBM. Filenames are
!! 'DATA_YYY_XXXXXXX.VTK' where YYY is the processor number and XXXXXXX is the
!! time step. These files are understood by Paraview.

SUBROUTINE VtkDump

! Common Variables
 USE Ntypes,      ONLY : DBL
 USE Domain
 USE FluidParams, ONLY : alpha, kappa, phi, phiStar2, phiStar4
 USE LBMParams,   ONLY : Cs_sq, g
 IMPLICIT NONE

! Required functions
 CHARACTER(12) :: filer

! Local Variables
 INTEGER :: i, j, k, ie, iw, jn, js, kt, kb
 INTEGER :: IO_ERR
 REAL(KIND = DBL) :: ux, uy, uz, phin, phin2, pressure, rhon, invRhon, x
 REAL(KIND = DBL) :: gradPhiX, gradPhiY, gradPhiZ, gradPhiSq, lapPhi
 REAL(KIND = DBL) :: in00, in01, in02, in03, in04, in05, in06, in07, in08, in09
 REAL(KIND = DBL) :: in10, in11, in12, in13, in14, in15, in16, in17, in18 ,xx, zz
 CHARACTER(12) :: filer1
 CHARACTER(16) :: fmtd1, fmtd3
 CHARACTER(20) :: filer2


! Set output files formats and names
 fmtd1 = '(1(ES21.11E3))'
 fmtd3 = '(3(ES21.11E3))'
 filer1 = filer()
 filer2 = "DATA"//filer1(1:12)//".dat"

 OPEN(UNIT = 12, FILE = filer2, STATUS = "NEW", POSITION = "APPEND", &
      IOSTAT = IO_ERR)
 IF ( IO_ERR == 0 ) THEN
   !WRITE(12,'(A)')"# vtk DataFile Version 2.0"
   !WRITE(12,'(A)')"MP-LABS v1.0"
   !WRITE(12,'(A)')"ASCII"
   WRITE(12,*)"Variables =X,  Y, Z, Phi"
   WRITE(12,10)NX,NY,NZ
   10 FORMAT("Zone i=", I3,"j=", I3,"k=" I3,"F=POINT")
   !WRITE(12,'(A)')"DATASET STRUCTURED_POINTS"
   !WRITE(12,*)"DIMENSIONS",NPX,NPZ,1
   !WRITE(12,*)"ORIGIN",xmin,1,zmin
   !WRITE(12,*)"SPACING",xjump,xjump,xjump
   !WRITE(12,*)
   !WRITE(12,*)"POINT_DATA",NPX*1*NPZ
   !WRITE(12,*)
   !WRITE(12,'(A)')"SCALARS Phi double"
   !WRITE(12,'(A)')"LOOKUP_TABLE default"
  
      
         DO k = zmin, zmax
			DO j = ymin, ymax 
			DO i= xmin, xmax
		 if (i .gt. (xmin +50) .and. i.lt. (xmax - 50) .and. k .lt. (zmax -50))then
			xx = 0.0d0
			else
			xx = phi(i,j,k)
			end if
            

			
			WRITE( 12,*)i,j,k,xx
			END DO
         END DO
      END DO
   
  ! WRITE(12,*)
   !WRITE(12,'(A)')"SCALARS Pressure double"
  ! WRITE(12,'(A)')"LOOKUP_TABLE default"
   
     
      !   DO j = zmin, zmax, xjump
		!  DO i = xmin, xmax, xjump
           ! rhon  = SUM( g(i,ymax/2,j,:,now) )
           ! phin  = phi(i,ymax/2,j)
           ! phin2 = phin*phin

! Identify neighbours
          !  ie = ni(i,ymax/2,j,1)
          !  iw = ni(i,ymax/2,j,2)
           ! jn = ni(i,ymax/2,j,3)
           ! js = ni(i,ymax/2,j,4)
           ! kt = ni(i,ymax/2,j,5)
           ! kb = ni(i,ymax/2,j,6)

! Nodal values of the order parameter
            !in00 = phi(i ,ymax/2,j )
            !in01 = phi(ie,ymax/2,j )
            !in02 = phi(iw,ymax/2,j )
            !in03 = phi(i ,jn,j )
            !in04 = phi(i ,js,j )
            !in05 = phi(i ,ymax/2 ,kt)
            !in06 = phi(i ,ymax/2 ,kb)
            !in07 = phi(ie,jn,j )
            !in08 = phi(iw,js,j )
            !in09 = phi(ie,js,j )
            !in10 = phi(iw,jn,j )
            !in11 = phi(ie,ymax/2 ,kt)
            !in12 = phi(iw,ymax/2 ,kb)
            !in13 = phi(ie,ymax/2 ,kb)
            !in14 = phi(iw,ymax/2 ,kt)
            !in15 = phi(i ,jn,kt)
            !in16 = phi(i ,js,kb)
            !in17 = phi(i ,jn,kb)
            !in18 = phi(i ,js,kt)

! Laplacian of the order parameter
            !lapPhi = ( in07 + in08 + in09 + in10 + in11 + in12 + in13 + in14 &
            !       + in15 + in16 + in17 + in18 + 2.0D0*( in01 + in02 + in03  &
            !       + in04 + in05 + in06 - 12.D0*in00 ) )*inv36

! Components of the order parameter gradient
            !gradPhiX  = ( 2.0D0*( in01 - in02 ) + in07 - in08 + in09 - in10 &
            !          + in11 - in12 + in13 - in14 )*inv12

            !gradPhiY  = ( 2.0D0*( in03 - in04 ) + in07 - in08 + in10 - in09 &
            !          + in15 - in16 + in17 - in18 )*inv12

            !gradPhiZ  = ( 2.0D0*( in05 - in06 ) + in11 - in12 + in14 - in13 &
            !          + in15 - in16 + in18 - in17 )*inv12

            !gradPhiSq = gradPhiX*gradPhiX + gradPhiY*gradPhiY + gradPhiZ*gradPhiZ

! Calculate the pressure
            !pressure = alpha*( phin2*( 3.D0*phin2 - 2.D0*phiStar2 ) - phiStar4 ) &
            !         - kappa*( phin*lapPhi - 0.5D0*gradPhiSq ) + Cs_sq*rhon

	!		if (i .gt. (xmin +50) .and. i.lt. (xmax - 50) .and. j .lt. (zmax -50))then
	!		xx = 0.0d0
	!		else
	!		xx = pressure
	!		end if
			
	!		WRITE(UNIT = 12,FMT = fmtd1)xx
        ! END DO
      !END DO
   
   !WRITE(12,*)
   !WRITE(12,'(A)')"VECTORS Velocity double"
  
      
   !      DO j = zmin, zmax, xjump
!		 DO i = xmin, xmax, xjump

   !        rhon = SUM( g(i,ymax/2,j,:,now) )
   !        invRhon = 1.D0/rhon

   !        ux = ( g(i,ymax/2,j, 1,now) - g(i,ymax/2,j, 2,now) + g(i,ymax/2,j, 7,now) &
   !           -   g(i,ymax/2,j, 8,now) + g(i,ymax/2,j, 9,now) - g(i,ymax/2,j,10,now) &
   !           +   g(i,ymax/2,j,11,now) - g(i,ymax/2,j,12,now) + g(i,ymax/2,j,13,now) &
   !           - g(i,ymax/2,j,14,now) )*invRhon

   !        uy = ( g(i,ymax/2,j, 3,now) - g(i,ymax/2,j, 4,now) + g(i,ymax/2,j, 7,now) &
   !           -   g(i,ymax/2,j, 8,now) - g(i,ymax/2,j, 9,now) + g(i,ymax/2,j,10,now) &
   !           +   g(i,ymax/2,j,15,now) - g(i,ymax/2,j,16,now) + g(i,ymax/2,j,17,now) &
   !           - g(i,ymax/2,j,18,now) )*invRhon

   !        uz = ( g(i,ymax/2,j, 5,now) - g(i,ymax/2,j, 6,now) + g(i,ymax/2,j,11,now) &
   !           -   g(i,ymax/2,j,12,now) - g(i,ymax/2,j,13,now) + g(i,ymax/2,j,14,now) &
   !           +   g(i,ymax/2,j,15,now) - g(i,ymax/2,j,16,now) - g(i,ymax/2,j,17,now) &
   !           + g(i,ymax/2,j,18,now) )*invRhon

			  
!		if (i .gt. (xmin +50) .and. i.lt. (xmax - 50) .and. j .lt. (zmax -50))then
!			xx = 0.0d0
!			zz = 0.0d0
!			else
!			xx = ux
!			zz = uz
!			end if
            
			
!			WRITE(UNIT = 12,FMT = fmtd3)xx,0.0D0,zz
   !      END DO
   !   END DO
  
   !CLOSE(UNIT = 12)
 ELSE
   CALL MemAlloc(2)
   STOP "Error: Unable to open output data file."
 END IF

 RETURN
 END SUBROUTINE VtkDump

!-------------------------------------------------------------------------------
! Function : filer
! Revision : 1.0 (2008-06-15)
! Author   : David S. Whyte [david(at)ihpc.a-star.edu.sg]
!-------------------------------------------------------------------------------
!> @brief Set vtk file name as a function of processor number and time step.
 FUNCTION filer()

! Common variables
 USE Domain,    ONLY : iStep
 IMPLICIT NONE

! Function type
 CHARACTER(12) :: filer

!-------- Files name depending on processor (vproc) and timestep (iStep) -------
 
   IF (iStep < 10) THEN
     WRITE(filer,9001)iStep
   ELSE IF (iStep < 100) THEN
     WRITE(filer,9002)iStep
   ELSE IF (iStep < 1000) THEN
     WRITE(filer,9003)iStep
   ELSE IF (iStep < 10000) THEN
     WRITE(filer,9004)iStep
   ELSE IF (iStep < 100000) THEN
     WRITE(filer,9005)iStep
   ELSE IF (iStep < 1000000) THEN
     WRITE(filer,9006)iStep
   ELSE IF (iStep < 10000000) THEN
     WRITE(filer,9007)iStep
   END IF
 

!-------- File name format depending on processor (vproc) and timestep (iStep) -
 9001 FORMAT('_000000',i1)
 9002 FORMAT('_00000',i2)
 9003 FORMAT('_0000',i3)
 9004 FORMAT('_000',i4)
 9005 FORMAT('_00',i5)
 9006 FORMAT('_0',i6)
 9007 FORMAT('_',i7)
 

 RETURN
 END FUNCTION filer
!-------------------------------------------------------------------------------------------------------
!-------------------------------------------------------------------------------
! Subroutine : Collision
!-------------------------------------------------------------------------------
!> @file
!! Collision (f,g), streaming (g), and hydrodynamics (p,phi,rho,u) calculation
!> @details
!! Collision step for order parameter distribution function f, collision and
!! streaming steps for momentum distribution function g, and calculation of
!! updated macroscopic quantities (velocity, pressure and order parameter) in
!! the parallel D3Q7/D3Q19 Zheng-Shu-Chew multiphase LBM including gravity.

 SUBROUTINE Collision

!  Common Variables
 USE NTypes,      ONLY : DBL
 USE Domain,      ONLY : inv12, inv36, ni, now, nxt, xmin, xmax, ymin, ymax, zmin, zmax
 USE FluidParams
 USE LBMParams,   ONLY : Eg0n, Eg1n, Eg2n, EgC0n, EgC1n, EgC2n, invCs_sq, f, g
 IMPLICIT NONE

!  Local Variables
 INTEGER :: i, j, k, ie, iw, jn, js, kt, kb
 REAL(KIND = DBL) :: muPhin, phin, phin2
 REAL(KIND = DBL) :: rhon, invRhon
 REAL(KIND = DBL) :: sFx, sFy, sFz
 REAL(KIND = DBL) :: UF, ux, uy, uz, Vg, Vsq
 REAL(KIND = DBL) :: Af0, Af1, Ag0, Ag1, Cf1
 REAL(KIND = DBL) :: Eg1A, Eg2A, Eg1R, Eg2R
 REAL(KIND = DBL) :: geq1, geq2, gradPhiX, gradPhiY, gradPhiZ, lapPhi
 REAL(KIND = DBL) :: in01, in02, in03, in04, in05, in06, in07, in08, in09
 REAL(KIND = DBL) :: in10, in11, in12, in13, in14, in15, in16, in17, in18
 REAL(KIND = DBL) :: c1 (75,75,18)


! Order parameter update
 DO k = zmin, zmax
   DO j = ymin, ymax
     DO i = xmin, xmax
       phi(i,j,k) = SUM( f(i,j,k,:,now) )

	   if (phi (i,j,k) .gt. 106.5d0 ) phi (i,j,k) = 106.5d0
	   if (phi (i,j,k) .lt. -106.5d0 ) phi (i,j,k) = -106.5d0

	      END DO
   END DO
 END DO
 
 

 DO k = zmin, zmax
   DO j = ymin, ymax
     DO i = xmin, xmax

	 if (i .gt. (xmin +50) .and. i.lt. (xmax - 50) .and. k .lt. (zmax -50))then
			continue
			else

! Define some local values
       phin    = phi(i,j,k)
       phin2   = phin*phin
       rhon    = SUM( g(i,j,k,:,now) )
       invRhon = 1.D0/rhon

!-------- Differential terms ---------------------------------------------------
! Identify neighbours
       ie = ni(i,j,k,1)
       iw = ni(i,j,k,2)
       jn = ni(i,j,k,3)
       js = ni(i,j,k,4)
       kt = ni(i,j,k,5)
       kb = ni(i,j,k,6)

! Nodal phi values
       in01 = phi(ie,j ,k )
       in02 = phi(iw,j ,k )
       in03 = phi(i ,jn,k )
       in04 = phi(i ,js,k )
       in05 = phi(i ,j ,kt)
       in06 = phi(i ,j ,kb)
       in07 = phi(ie,jn,k )
       in08 = phi(iw,js,k )
       in09 = phi(ie,js,k )
       in10 = phi(iw,jn,k )
       in11 = phi(ie,j ,kt)
       in12 = phi(iw,j ,kb)
       in13 = phi(ie,j ,kb)
       in14 = phi(iw,j ,kt)
       in15 = phi(i ,jn,kt)
       in16 = phi(i ,js,kb)
       in17 = phi(i ,jn,kb)
       in18 = phi(i ,js,kt)

! Laplacian of the order parameter phi
       lapPhi = ( in07 + in08 + in09 + in10 + in11 + in12 + in13 + in14 + in15 &
              + in16 + in17 + in18 + 2.0D0*( in01 + in02 + in03 + in04 + in05  &
              + in06 - 12.D0*phin ) )*inv36

! Gradient components of the order parameter phi
       gradPhiX = ( 2.0D0*( in01 - in02 ) + in07 - in08 + in09 - in10 + in11 &
                - in12 + in13 - in14 )*inv12

       gradPhiY = ( 2.0D0*( in03 - in04 ) + in07 - in08 + in10 - in09 + in15 &
                - in16 + in17 - in18 )*inv12

       gradPhiZ = ( 2.0D0*( in05 - in06 ) + in11 - in12 + in14 - in13 + in15 &
                - in16 + in18 - in17 )*inv12

!-------- Hydrodynamics (velocity, pressure, interfacial force) ----------------
! Chemical potential
       muphin = alpha4*phin*( phin2 - phiStar2 ) - kappa*lapPhi

! Interfacial force and gravity
       sFx = muPhin*gradPhiX
       sFy = muPhin*gradPhiY
       sFz = muPhin*gradPhiZ
       IF (phin > 0.D0) sFz = sFz + gravZ
	   IF (phin > 0.D0) sFx = sFx + gravX

! Velocity
       ux = ( g(i,j,k, 1,now) - g(i,j,k, 2,now) + g(i,j,k, 7,now) &
          -   g(i,j,k, 8,now) + g(i,j,k, 9,now) - g(i,j,k,10,now) &
          +   g(i,j,k,11,now) - g(i,j,k,12,now) + g(i,j,k,13,now) &
          -   g(i,j,k,14,now) + 0.5D0*sFx )*invRhon

       uy = ( g(i,j,k, 3,now) - g(i,j,k, 4,now) + g(i,j,k, 7,now) &
          -   g(i,j,k, 8,now) - g(i,j,k, 9,now) + g(i,j,k,10,now) &
          +   g(i,j,k,15,now) - g(i,j,k,16,now) + g(i,j,k,17,now) &
          - g(i,j,k,18,now) + 0.5D0*sFy )*invRhon

       uz = ( g(i,j,k, 5,now) - g(i,j,k, 6,now) + g(i,j,k,11,now) &
          -   g(i,j,k,12,now) - g(i,j,k,13,now) + g(i,j,k,14,now) &
          +   g(i,j,k,15,now) - g(i,j,k,16,now) - g(i,j,k,17,now) &
          + g(i,j,k,18,now) + 0.5D0*sFz )*invRhon


!-------- Collision for order parameter distribution function f ----------------
       Af0 = -3.D0*Gamma*muPhin*invTauPhi
       Af1 = 0.5D0*Gamma*muPhin*invTauPhi
       Cf1 = invTauPhi*invEta2*phin


       f(i,j,k,0,nxt) = invTauPhi1*f(i,j,k,0,now) + Af0 + invTauPhi*phin
       f(i,j,k,1,now) = invTauPhi1*f(i,j,k,1,now) + Af1 + Cf1*ux
       f(i,j,k,2,now) = invTauPhi1*f(i,j,k,2,now) + Af1 - Cf1*ux
       f(i,j,k,3,now) = invTauPhi1*f(i,j,k,3,now) + Af1 + Cf1*uy
       f(i,j,k,4,now) = invTauPhi1*f(i,j,k,4,now) + Af1 - Cf1*uy
       f(i,j,k,5,now) = invTauPhi1*f(i,j,k,5,now) + Af1 + Cf1*uz
       f(i,j,k,6,now) = invTauPhi1*f(i,j,k,6,now) + Af1 - Cf1*uz

	   

!-------- Collision for momentum distribution function g -----------------------
! The factor invTauRho for geq is embedded in Egn
       Ag0  = rhon - 6.D0*phin*muPhin
       Ag1  = 3.D0*phin*muPhin + rhon
       Eg1A = Eg1n*Ag1
       Eg2A = Eg2n*Ag1
       Eg1R = Eg1n*rhon
       Eg2R = Eg2n*rhon
       Vsq  = 1.5D0*( ux*ux + uy*uy + uz*uz )
       UF   = ux*sFx + uy*sFy + uz*sFz

! Rescale velocity to avoid unnecessary product operations
       ux = ux*invCs_sq
       uy = uy*invCs_sq
       uz = uz*invCs_sq

! The equilibrium g value and the force are bundled into gFs
! DIRECTION 0
       g(i,j,k,0,nxt) = invTauRhoOne*g(i,j,k,0,now) + Eg0n*( Ag0 - rhon*Vsq ) &
                      - EgC0n*UF

! DIRECTIONS 1 & 2
       geq1 = Eg1A + Eg1R*( 0.5D0*ux*ux - Vsq )
       geq2 = Eg1R*ux

       g(ie,j,k,1,nxt) = invTauRhoOne*g(i,j,k,1,now) + geq1 + geq2 &
                       + EgC1n*( ( 1.D0 + ux )*sFx - UF )

       g(iw,j,k,2,nxt) = invTauRhoOne*g(i,j,k,2,now) + geq1 - geq2 &
                       + EgC1n*( (-1.D0 + ux )*sFx - UF )

! DIRECTIONS 3 & 4
       geq1 = Eg1A + Eg1R*( 0.5D0*uy*uy - Vsq )
       geq2 = Eg1R*uy

       g(i,jn,k,3,nxt) = invTauRhoOne*g(i,j,k,3,now) + geq1 + geq2 &
                       + EgC1n*( ( 1.D0 + uy )*sFy - UF )

       g(i,js,k,4,nxt) = invTauRhoOne*g(i,j,k,4,now) + geq1 - geq2 &
                       + EgC1n*( (-1.D0 + uy )*sFy - UF )

! DIRECTIONS 5 & 6
       geq1 = Eg1A + Eg1R*( 0.5D0*uz*uz - Vsq )
       geq2 = Eg1R*uz

       g(i,j,kt,5,nxt) = invTauRhoOne*g(i,j,k,5,now) + geq1 + geq2 &
                       + EgC1n*( ( 1.D0 + uz )*sFz - UF )

       g(i,j,kb,6,nxt) = invTauRhoOne*g(i,j,k,6,now) + geq1 - geq2 &
                       + EgC1n*( (-1.D0 + uz )*sFz - UF )
	 
	  

! DIRECTION 7 & 8
       Vg   = ux + uy
       geq1 = Eg2A + Eg2R*( 0.5D0*Vg*Vg - Vsq )
       geq2 = Eg2R*Vg

       g(ie,jn,k,7,nxt) = invTauRhoOne*g(i,j,k,7,now) + geq1 + geq2 &
                        + EgC2n*( ( 1.D0 + Vg )*( sFx + sFy ) - UF )

       g(iw,js,k,8,nxt) = invTauRhoOne*g(i,j,k,8,now) + geq1 - geq2 &
                        + EgC2n*( (-1.D0 + Vg )*( sFx + sFy ) - UF )

! DIRECTIONS 9 & 10
       Vg   = ux - uy
       geq1 = Eg2A + Eg2R*( 0.5D0*Vg*Vg - Vsq )
       geq2 = Eg2R*Vg

       g(ie,js,k,9,nxt)  = invTauRhoOne*g(i,j,k,9,now) + geq1 + geq2  &
                         + EgC2n*( ( 1.D0 + Vg )*( sFx - sFy ) - UF )

       g(iw,jn,k,10,nxt) = invTauRhoOne*g(i,j,k,10,now) + geq1 - geq2 &
                         + EgC2n*( (-1.D0 + Vg )*( sFx - sFy ) - UF )

! DIRECTIONS 11 & 12
       Vg   = ux + uz
       geq1 = Eg2A + Eg2R*( 0.5D0*Vg*Vg - Vsq )
       geq2 = Eg2R*Vg

       g(ie,j,kt,11,nxt) = invTauRhoOne*g(i,j,k,11,now) + geq1 + geq2 &
                         + EgC2n*( ( 1.D0 + Vg )*( sFx + sFz ) - UF )

       g(iw,j,kb,12,nxt) = invTauRhoOne*g(i,j,k,12,now) + geq1 - geq2 &
                         + EgC2n*( (-1.D0 + Vg )*( sFx + sFz ) - UF )

! DIRECTIONS 13 & 14
       Vg   = ux - uz
       geq1 = Eg2A + Eg2R*( 0.5D0*Vg*Vg - Vsq )
       geq2 = Eg2R*Vg

       g(ie,j,kb,13,nxt) = invTauRhoOne*g(i,j,k,13,now) + geq1 + geq2 &
                         + EgC2n*( ( 1.D0 + Vg )*( sFx - sFz ) - UF )

       g(iw,j,kt,14,nxt) = invTauRhoOne*g(i,j,k,14,now) + geq1 - geq2 &
                         + EgC2n*( (-1.D0 + Vg )*( sFx - sFz ) - UF )
! DIRECTIONS 15 & 16
       Vg   = uy + uz
       geq1 = Eg2A + Eg2R*( 0.5D0*Vg*Vg - Vsq )
       geq2 = Eg2R*Vg

       g(i,jn,kt,15,nxt) = invTauRhoOne*g(i,j,k,15,now) + geq1 + geq2 &
                         + EgC2n*( ( 1.D0 + Vg )*( sFy + sFz ) - UF )

       g(i,js,kb,16,nxt) = invTauRhoOne*g(i,j,k,16,now) + geq1 - geq2 &
                         + EgC2n*( (-1.D0 + Vg )*( sFy + sFz ) - UF )

! DIRECTIONS 17 & 18
       Vg   = uy - uz
       geq1 = Eg2A + Eg2R*( 0.5D0*Vg*Vg - Vsq )
       geq2 = Eg2R*Vg

       g(i,jn,kb,17,nxt) = invTauRhoOne*g(i,j,k,17,now) + geq1 + geq2 &
                         + EgC2n*( ( 1.D0 + Vg )*( sFy - sFz ) - UF )

       g(i,js,kt,18,nxt) = invTauRhoOne*g(i,j,k,18,now) + geq1 - geq2 &
                         + EgC2n*( (-1.D0 + Vg )*( sFy - sFz ) - UF )

	endif

     END DO
   END DO
 END DO
 
 

 
 
 !For Wall B.C. up to zmax
	DO i = xmin, xmax 
	   DO j = ymin, ymax
		 DO k = zmin, zmax
		 
		 if (i.eq.xmin)then
		 
			g(i,j,k,1,nxt)=g(i,j,k,2,nxt)
			g(i,j,k,3,nxt)=g(i,j,k,4,nxt)
			g(i,j,k,5,nxt)=g(i,j,k,6,nxt)
			g(i,j,k,7,nxt)=g(i,j,k,8,nxt)
			g(i,j,k,9,nxt)=g(i,j,k,10,nxt)
			g(i,j,k,11,nxt)=g(i,j,k,12,nxt)
			g(i,j,k,13,nxt)=g(i,j,k,14,nxt)
			g(i,j,k,15,nxt)=g(i,j,k,16,nxt)
			g(i,j,k,17,nxt)=g(i,j,k,18,nxt)

			g(i,j,k,2,nxt)=g(i,j,k,1,nxt)
			g(i,j,k,4,nxt)=g(i,j,k,3,nxt)
			g(i,j,k,6,nxt)=g(i,j,k,5,nxt)
			g(i,j,k,8,nxt)=g(i,j,k,7,nxt)
			g(i,j,k,10,nxt)=g(i,j,k,9,nxt)
			g(i,j,k,12,nxt)=g(i,j,k,11,nxt)
			g(i,j,k,14,nxt)=g(i,j,k,13,nxt)
			g(i,j,k,16,nxt)=g(i,j,k,15,nxt)
			g(i,j,k,18,nxt)=g(i,j,k,17,nxt)
			
		elseif (i.eq.xmax)then

			g(i,j,k,2,nxt)=g(i,j,k,1,nxt)
			g(i,j,k,4,nxt)=g(i,j,k,3,nxt)
			g(i,j,k,6,nxt)=g(i,j,k,5,nxt)
			g(i,j,k,8,nxt)=g(i,j,k,7,nxt)
			g(i,j,k,10,nxt)=g(i,j,k,9,nxt)
			g(i,j,k,12,nxt)=g(i,j,k,11,nxt)
			g(i,j,k,14,nxt)=g(i,j,k,13,nxt)
			g(i,j,k,16,nxt)=g(i,j,k,15,nxt)
			g(i,j,k,18,nxt)=g(i,j,k,17,nxt)

			g(i,j,k,1,nxt)=g(i,j,k,2,nxt)
			g(i,j,k,3,nxt)=g(i,j,k,4,nxt)
			g(i,j,k,5,nxt)=g(i,j,k,6,nxt)
			g(i,j,k,7,nxt)=g(i,j,k,8,nxt)
			g(i,j,k,9,nxt)=g(i,j,k,10,nxt)
			g(i,j,k,11,nxt)=g(i,j,k,12,nxt)
			g(i,j,k,13,nxt)=g(i,j,k,14,nxt)
			g(i,j,k,15,nxt)=g(i,j,k,16,nxt)
			g(i,j,k,17,nxt)=g(i,j,k,18,nxt)
			
		elseif (j.eq.ymin)then
			
			g(i,j,k,2,nxt)=g(i,j,k,1,nxt)
			g(i,j,k,3,nxt)=g(i,j,k,4,nxt)
			g(i,j,k,6,nxt)=g(i,j,k,5,nxt)
			g(i,j,k,7,nxt)=g(i,j,k,8,nxt)
			g(i,j,k,10,nxt)=g(i,j,k,9,nxt)
			g(i,j,k,12,nxt)=g(i,j,k,11,nxt)
			g(i,j,k,14,nxt)=g(i,j,k,13,nxt)
			g(i,j,k,15,nxt)=g(i,j,k,16,nxt)
			g(i,j,k,17,nxt)=g(i,j,k,18,nxt)

			g(i,j,k,1,nxt)=g(i,j,k,2,nxt)
			g(i,j,k,4,nxt)=g(i,j,k,3,nxt)
			g(i,j,k,5,nxt)=g(i,j,k,6,nxt)
			g(i,j,k,8,nxt)=g(i,j,k,7,nxt)
			g(i,j,k,9,nxt)=g(i,j,k,10,nxt)
			g(i,j,k,11,nxt)=g(i,j,k,12,nxt)
			g(i,j,k,13,nxt)=g(i,j,k,14,nxt)
			g(i,j,k,16,nxt)=g(i,j,k,15,nxt)
			g(i,j,k,18,nxt)=g(i,j,k,17,nxt)
			
		elseif (j.eq.ymax)then

			g(i,j,k,1,nxt)=g(i,j,k,2,nxt)
			g(i,j,k,4,nxt)=g(i,j,k,3,nxt)
			g(i,j,k,5,nxt)=g(i,j,k,6,nxt)
			g(i,j,k,8,nxt)=g(i,j,k,7,nxt)
			g(i,j,k,9,nxt)=g(i,j,k,10,nxt)
			g(i,j,k,11,nxt)=g(i,j,k,12,nxt)
			g(i,j,k,13,nxt)=g(i,j,k,14,nxt)
			g(i,j,k,16,nxt)=g(i,j,k,15,nxt)
			g(i,j,k,18,nxt)=g(i,j,k,17,nxt)

			g(i,j,k,2,nxt)=g(i,j,k,1,nxt)
			g(i,j,k,3,nxt)=g(i,j,k,4,nxt)
			g(i,j,k,6,nxt)=g(i,j,k,5,nxt)
			g(i,j,k,7,nxt)=g(i,j,k,8,nxt)
			g(i,j,k,10,nxt)=g(i,j,k,9,nxt)
			g(i,j,k,12,nxt)=g(i,j,k,11,nxt)
			g(i,j,k,14,nxt)=g(i,j,k,13,nxt)
			g(i,j,k,15,nxt)=g(i,j,k,16,nxt)
			g(i,j,k,17,nxt)=g(i,j,k,18,nxt)
			
			else

			continue

			endif
 
         END DO
	   END DO
	END DO

	!For Wall B.C. up to zmax -50 at xmax -50 and xmin +50
	DO i = xmin, xmax 
	   DO j = ymin, ymax
		 DO k = zmin, zmax - 50
		 
		 if (i.eq. (xmax - 50))then
		 
			g(i,j,k,1,nxt)=g(i,j,k,2,nxt)
			g(i,j,k,3,nxt)=g(i,j,k,4,nxt)
			g(i,j,k,5,nxt)=g(i,j,k,6,nxt)
			g(i,j,k,7,nxt)=g(i,j,k,8,nxt)
			g(i,j,k,9,nxt)=g(i,j,k,10,nxt)
			g(i,j,k,11,nxt)=g(i,j,k,12,nxt)
			g(i,j,k,13,nxt)=g(i,j,k,14,nxt)
			g(i,j,k,15,nxt)=g(i,j,k,16,nxt)
			g(i,j,k,17,nxt)=g(i,j,k,18,nxt)

			g(i,j,k,2,nxt)=g(i,j,k,1,nxt)
			g(i,j,k,4,nxt)=g(i,j,k,3,nxt)
			g(i,j,k,6,nxt)=g(i,j,k,5,nxt)
			g(i,j,k,8,nxt)=g(i,j,k,7,nxt)
			g(i,j,k,10,nxt)=g(i,j,k,9,nxt)
			g(i,j,k,12,nxt)=g(i,j,k,11,nxt)
			g(i,j,k,14,nxt)=g(i,j,k,13,nxt)
			g(i,j,k,16,nxt)=g(i,j,k,15,nxt)
			g(i,j,k,18,nxt)=g(i,j,k,17,nxt)
			

		elseif (i.eq.(xmin + 50))then

			g(i,j,k,2,nxt)=g(i,j,k,1,nxt)
			g(i,j,k,4,nxt)=g(i,j,k,3,nxt)
			g(i,j,k,6,nxt)=g(i,j,k,5,nxt)
			g(i,j,k,8,nxt)=g(i,j,k,7,nxt)
			g(i,j,k,10,nxt)=g(i,j,k,9,nxt)
			g(i,j,k,12,nxt)=g(i,j,k,11,nxt)
			g(i,j,k,14,nxt)=g(i,j,k,13,nxt)
			g(i,j,k,16,nxt)=g(i,j,k,15,nxt)
			g(i,j,k,18,nxt)=g(i,j,k,17,nxt)

			g(i,j,k,1,nxt)=g(i,j,k,2,nxt)
			g(i,j,k,3,nxt)=g(i,j,k,4,nxt)
			g(i,j,k,5,nxt)=g(i,j,k,6,nxt)
			g(i,j,k,7,nxt)=g(i,j,k,8,nxt)
			g(i,j,k,9,nxt)=g(i,j,k,10,nxt)
			g(i,j,k,11,nxt)=g(i,j,k,12,nxt)
			g(i,j,k,13,nxt)=g(i,j,k,14,nxt)
			g(i,j,k,15,nxt)=g(i,j,k,16,nxt)
			g(i,j,k,17,nxt)=g(i,j,k,18,nxt)
			
			else

			continue

			endif
 
         END DO
	   END DO
	END DO
	
! B.C. for Zmin 	
	DO i = xmin+50, xmax-50
       DO j = ymin, ymax
	   
			g(i,j,zmin,1,nxt)=g(i,j,zmin,2,nxt)
			g(i,j,zmin,3,nxt)=g(i,j,zmin,4,nxt)
			g(i,j,zmin,5,nxt)=g(i,j,zmin,6,nxt)
			g(i,j,zmin,7,nxt)=g(i,j,zmin,8,nxt)
			g(i,j,zmin,9,nxt)=g(i,j,zmin,10,nxt)
			g(i,j,zmin,11,nxt)=g(i,j,zmin,12,nxt)
			g(i,j,zmin,14,nxt)=g(i,j,zmin,13,nxt)
			g(i,j,zmin,15,nxt)=g(i,j,zmin,16,nxt)
			g(i,j,zmin,18,nxt)=g(i,j,zmin,17,nxt)
			
			g(i,j,zmin,2,nxt)=g(i,j,zmin,1,nxt)
			g(i,j,zmin,4,nxt)=g(i,j,zmin,3,nxt)
			g(i,j,zmin,6,nxt)=g(i,j,zmin,5,nxt)
			g(i,j,zmin,8,nxt)=g(i,j,zmin,7,nxt)
			g(i,j,zmin,10,nxt)=g(i,j,zmin,9,nxt)
			g(i,j,zmin,12,nxt)=g(i,j,zmin,11,nxt)
			g(i,j,zmin,13,nxt)=g(i,j,zmin,14,nxt)
			g(i,j,zmin,16,nxt)=g(i,j,zmin,15,nxt)
			g(i,j,zmin,17,nxt)=g(i,j,zmin,18,nxt)
			
		END DO
	END DO

! B.C. for Zmin 	
	DO i = xmin, xmin +50
       DO j = ymin, ymax
	   
	       c1(i,j,2)=g(xmax -50+i,j,zmin,2,nxt)
			!g(xmax -50+i,j,zmin,2,nxt)=g(i,j,zmin,1,nxt)
		
            c1(i,j,4)=g(xmax -50+i,j,zmin,4,nxt)
			!g(xmax -50+i,j,zmin,4,nxt)=g(i,j,zmin,3,nxt)
			
			c1(i,j,6)=g(xmax -50+i,j,zmin,6,nxt)
			!g(xmax -50+i,j,zmin,6,nxt)=g(i,j,zmin,5,nxt)
			
			c1(i,j,8)=g(xmax -50+i,j,zmin,8,nxt)
			!g(xmax -50+i,j,zmin,8,nxt)=g(i,j,zmin,7,nxt)
			
			c1(i,j,10)=g(xmax -50+i,j,zmin,10,nxt)
			!g(xmax -50+i,j,zmin,10,nxt)=g(i,j,zmin,9,nxt)
			
			c1(i,j,12)=g(xmax -50+i,j,zmin,12,nxt)
			!g(xmax -50+i,j,zmin,12,nxt)=g(i,j,zmin,11,nxt)
			
			c1(i,j,13)=g(xmax -50+i,j,zmin,13,nxt)
            !g(xmax -50+i,j,zmin,13,nxt)=g(i,j,zmin,14,nxt)
	    
			c1(i,j,16)=g(xmax -50+i,j,zmin,16,nxt)
		!g(xmax -50+i,j,zmin,16,nxt)=g(i,j,zmin,15,nxt)
			
            c1(i,j,17)=g(xmax -50+i,j,zmin,17,nxt)
		!g(xmax -50+i,j,zmin,17,nxt)=g(i,j,zmin,18,nxt)
			
			
			
			c1(i,j,1)=g(xmax -50+i,j,zmin,1,nxt)
		!g(xmax -50+i,j,zmin,1,nxt)=g(i,j,zmin,2,nxt)
		
            c1(i,j,3)=g(xmax -50+i,j,zmin,3,nxt)
		!g(xmax -50+i,j,zmin,3,nxt)=g(i,j,zmin,4,nxt)
			
			c1(i,j,5)=g(xmax -50+i,j,zmin,5,nxt)
			g(xmax -50+i,j,zmin,5,nxt)=g(i,j,zmin,6,nxt)
			
            c1(i,j,7)=g(xmax -50+i,j,zmin,7,nxt)
		!g(xmax -50+i,j,zmin,7,nxt)=g(i,j,zmin,8,nxt)
			
            c1(i,j,9)=g(xmax -50+i,j,zmin,9,nxt)
		!g(xmax -50+i,j,zmin,9,nxt)=g(i,j,zmin,10,nxt)
			

			c1(i,j,11)=g(xmax -50+i,j,zmin,11,nxt)
			g(xmax -50+i,j,zmin,11,nxt)=g(i,j,zmin,12,nxt)
			

			c1(i,j,14)=g(xmax -50+i,j,zmin,14,nxt)
			g(xmax -50+i,j,zmin,14,nxt)=g(i,j,zmin,13,nxt)
			

			c1(i,j,15)=g(xmax -50+i,j,zmin,15,nxt)
			g(xmax -50+i,j,zmin,15,nxt)=g(i,j,zmin,16,nxt)
			

			c1(i,j,18)=g(xmax -50+i,j,zmin,18,nxt)
			g(xmax -50+i,j,zmin,18,nxt)=g(i,j,zmin,17,nxt)
			
		
			
		END DO
	END DO

	! B.C. for Zmin 	
	DO i =  xmin,xmin+50
       DO j = ymin, ymax
	   
		!g(i,j,zmin,2,nxt)=c1(i,j,1)
		!g(i,j,zmin,1,nxt)=c1(i,j,2)
            
		!g(i,j,zmin,4,nxt)=c1(i,j,3)
		!g(i,j,zmin,3,nxt)=c1(i,j,4)

            !g(i,j,zmin,6,nxt)=c1(i,j,5)
			g(i,j,zmin,5,nxt)=c1(i,j,6)
         
            !g(i,j,zmin,8,nxt)=c1(i,j,7)
		!g(i,j,zmin,7,nxt)=c1(i,j,8)

            !g(i,j,zmin,10,nxt)=c1(i,j,9)
		!g(i,j,zmin,9,nxt)=c1(i,j,10)

		!g(i,j,zmin,12,nxt)=c1(i,j,11)
			g(i,j,zmin,11,nxt)=c1(i,j,12)

            !g(i,j,zmin,13,nxt)=c1(i,j,14)
			g(i,j,zmin,14,nxt)=c1(i,j,13)

            !g(i,j,zmin,16,nxt)=c1(i,j,15)
			g(i,j,zmin,15,nxt)=c1(i,j,16)

            !g(i,j,zmin,17,nxt)=c1(i,j,18)
			g(i,j,zmin,18,nxt)=c1(i,j,17)
			
			
		END DO
	END DO
	
	! B.C. for Zmax - 50	
	DO i = xmin +50, xmax -50
       DO j = ymin, ymax
	   
			g(i,j,zmax -50,1,nxt)=g(i,j,zmax -50,2,nxt)
			g(i,j,zmax -50,3,nxt)=g(i,j,zmax -50,4,nxt)
			g(i,j,zmax -50,5,nxt)=g(i,j,zmax -50,6,nxt)
			g(i,j,zmax -50,7,nxt)=g(i,j,zmax -50,8,nxt)
			g(i,j,zmax -50,9,nxt)=g(i,j,zmax -50,10,nxt)
			g(i,j,zmax -50,11,nxt)=g(i,j,zmax -50,12,nxt)
			g(i,j,zmax -50,14,nxt)=g(i,j,zmax -50,13,nxt)
			g(i,j,zmax -50,15,nxt)=g(i,j,zmax -50,16,nxt)
			g(i,j,zmax -50,18,nxt)=g(i,j,zmax -50,17,nxt)
			
			g(i,j,zmax -50,2,nxt)=g(i,j,zmax -50,1,nxt)
			g(i,j,zmax -50,4,nxt)=g(i,j,zmax -50,3,nxt)
			g(i,j,zmax -50,6,nxt)=g(i,j,zmax -50,5,nxt)
			g(i,j,zmax -50,8,nxt)=g(i,j,zmax -50,7,nxt)
			g(i,j,zmax -50,10,nxt)=g(i,j,zmax -50,9,nxt)
			g(i,j,zmax -50,12,nxt)=g(i,j,zmax -50,11,nxt)
			g(i,j,zmax -50,13,nxt)=g(i,j,zmax -50,14,nxt)
			g(i,j,zmax -50,16,nxt)=g(i,j,zmax -50,15,nxt)
			g(i,j,zmax -50,17,nxt)=g(i,j,zmax -50,18,nxt)
			
					
		END DO
	END DO
	
	
! B.C. for Zmax 
    DO i = xmin, xmax
       DO j = ymin, ymax

	   
			g(i,j,zmax,2,nxt)=g(i,j,zmax,1,nxt)
			g(i,j,zmax,4,nxt)=g(i,j,zmax,3,nxt)
			g(i,j,zmax,6,nxt)=g(i,j,zmax,5,nxt)
			g(i,j,zmax,8,nxt)=g(i,j,zmax,7,nxt)
			g(i,j,zmax,10,nxt)=g(i,j,zmax,9,nxt)
			g(i,j,zmax,12,nxt)=g(i,j,zmax,11,nxt)
			g(i,j,zmax,13,nxt)=g(i,j,zmax,14,nxt)
			g(i,j,zmax,16,nxt)=g(i,j,zmax,15,nxt)
			g(i,j,zmax,17,nxt)=g(i,j,zmax,18,nxt)

			g(i,j,zmax,1,nxt)=g(i,j,zmax,2,nxt)
			g(i,j,zmax,3,nxt)=g(i,j,zmax,4,nxt)
			g(i,j,zmax,5,nxt)=g(i,j,zmax,6,nxt)
			g(i,j,zmax,7,nxt)=g(i,j,zmax,8,nxt)
			g(i,j,zmax,9,nxt)=g(i,j,zmax,10,nxt)
			g(i,j,zmax,11,nxt)=g(i,j,zmax,12,nxt)
			g(i,j,zmax,14,nxt)=g(i,j,zmax,13,nxt)
			g(i,j,zmax,15,nxt)=g(i,j,zmax,16,nxt)
			g(i,j,zmax,18,nxt)=g(i,j,zmax,17,nxt)
			
		END DO
	END DO
 
 
 RETURN
 END SUBROUTINE Collision
!--------------------------------------------------------------------------------------------------------------
!-------------------------------------------------------------------------------
! Subroutine : Stream
!-------------------------------------------------------------------------------
!> @file
!! Relaxation and streaming steps for the distribution function f
!> @details
!! Relaxation and streaming step for distribution function f in the parallel
!! D3Q7/D3Q19 Zheng-Shu-Chew multiphase LBM.

SUBROUTINE Stream

! Common Variables
 USE NTypes,    ONLY : DBL
 USE Domain,      ONLY : ni, now, nxt, xmin, xmax, ymin, ymax, zmin, zmax
 USE FluidParams, ONLY : eta, eta2
 USE LBMParams,   ONLY : f
 IMPLICIT NONE

!  Local Variables
 INTEGER :: i, j, k, ie, iw, jn, js, kt, kb
 REAL(KIND = DBL) :: c2 (75,75,6)



 DO k = zmin, zmax
   DO j = ymin, ymax
     DO i = xmin, xmax

	  
 if (i .gt. (xmin +50) .and. i.lt. (xmax - 50) .and. k .lt. (zmax -50))then
			continue
			else
			 
		 

! Identify neighbours
       ie = ni(i,j,k,1)
       iw = ni(i,j,k,2)
       jn = ni(i,j,k,3)
       js = ni(i,j,k,4)
       kt = ni(i,j,k,5)
       kb = ni(i,j,k,6)

! Relax and stream the order paramter distribution f
       f(ie,j ,k ,1, nxt) = eta*f(i,j,k,1,now) + eta2*f(ie,j ,k ,1,now)
       f(iw,j ,k ,2, nxt) = eta*f(i,j,k,2,now) + eta2*f(iw,j ,k ,2,now)
       f(i ,jn,k ,3, nxt) = eta*f(i,j,k,3,now) + eta2*f(i ,jn,k ,3,now)
       f(i ,js,k ,4, nxt) = eta*f(i,j,k,4,now) + eta2*f(i ,js,k ,4,now)
       f(i ,j ,kt,5, nxt) = eta*f(i,j,k,5,now) + eta2*f(i ,j ,kt,5,now)
       f(i ,j ,kb,6, nxt) = eta*f(i,j,k,6,now) + eta2*f(i ,j ,kb,6,now)

endif

     END DO
   END DO
 END DO
 
 
 

!For Wall B.C. up to zmax
	DO i = xmin, xmax 
	   DO j = ymin, ymax
		 DO k = zmin, zmax

		 
		 
		 if (i.eq.xmin)then
			
			f(i,j,k,1,nxt)=f(i,j,k,2,nxt)
			f(i,j,k,3,nxt)=f(i,j,k,4,nxt)
			f(i,j,k,5,nxt)=f(i,j,k,6,nxt)
			
			f(i,j,k,2,nxt)=f(i,j,k,1,nxt)
			f(i,j,k,4,nxt)=f(i,j,k,3,nxt)
			f(i,j,k,6,nxt)=f(i,j,k,5,nxt)

		elseif (i.eq.xmax)then
			
			f(i,j,k,2,nxt)=f(i,j,k,1,nxt)
			f(i,j,k,4,nxt)=f(i,j,k,3,nxt)
			f(i,j,k,6,nxt)=f(i,j,k,5,nxt)

			f(i,j,k,1,nxt)=f(i,j,k,2,nxt)
			f(i,j,k,3,nxt)=f(i,j,k,4,nxt)
			f(i,j,k,5,nxt)=f(i,j,k,6,nxt)
		
		elseif (j.eq.ymin)then
			
			f(i,j,k,2,nxt)=f(i,j,k,1,nxt)
			f(i,j,k,3,nxt)=f(i,j,k,4,nxt)
			f(i,j,k,6,nxt)=f(i,j,k,5,nxt)

			f(i,j,k,1,nxt)=f(i,j,k,2,nxt)
			f(i,j,k,4,nxt)=f(i,j,k,3,nxt)
			f(i,j,k,5,nxt)=f(i,j,k,6,nxt)

		elseif (j.eq.ymax)then
			
			f(i,j,k,1,nxt)=f(i,j,k,2,nxt)
			f(i,j,k,4,nxt)=f(i,j,k,3,nxt)
			f(i,j,k,5,nxt)=f(i,j,k,6,nxt)

			f(i,j,k,2,nxt)=f(i,j,k,1,nxt)
			f(i,j,k,3,nxt)=f(i,j,k,4,nxt)
			f(i,j,k,6,nxt)=f(i,j,k,5,nxt)

			else
			continue

			endif
 
         END DO
	   END DO
	END DO

	!For Wall B.C. up to zmax -50 at xmax -50 and xmin +50
	DO i = xmin, xmax 
	   DO j = ymin, ymax
		 DO k = zmin, zmax - 50
		 
		 if (i.eq. (xmax - 50))then
		 
						
			f(i,j,k,1,nxt)=f(i,j,k,2,nxt)
			f(i,j,k,3,nxt)=f(i,j,k,4,nxt)
			f(i,j,k,5,nxt)=f(i,j,k,6,nxt)
			
			f(i,j,k,2,nxt)=f(i,j,k,1,nxt)
			f(i,j,k,4,nxt)=f(i,j,k,3,nxt)
			f(i,j,k,6,nxt)=f(i,j,k,5,nxt)

		elseif (i.eq.(xmin + 50))then

			f(i,j,k,2,nxt)=f(i,j,k,1,nxt)
			f(i,j,k,4,nxt)=f(i,j,k,3,nxt)
			f(i,j,k,6,nxt)=f(i,j,k,5,nxt)

			f(i,j,k,1,nxt)=f(i,j,k,2,nxt)
			f(i,j,k,3,nxt)=f(i,j,k,4,nxt)
			f(i,j,k,5,nxt)=f(i,j,k,6,nxt)
		
		
			else

			continue

			endif
 
         END DO
	   END DO
	END DO
	

! B.C. for Zmin 	
	DO i = xmin+50, xmax-50
       DO j = ymin, ymax
			
			f(i,j,zmin,1,nxt)=f(i,j,zmin,2,nxt)
			f(i,j,zmin,3,nxt)=f(i,j,zmin,4,nxt)
			f(i,j,zmin,5,nxt)=f(i,j,zmin,6,nxt)
			
			f(i,j,zmin,2,nxt)=f(i,j,zmin,1,nxt)
			f(i,j,zmin,4,nxt)=f(i,j,zmin,3,nxt)
			f(i,j,zmin,6,nxt)=f(i,j,zmin,5,nxt)
			
		END DO
	END DO

! B.C. for Zmin 	
	DO i = xmin, xmin +50
       DO j = ymin, ymax
	   
			c2(i,j,2)=f(xmax -50+i,j,zmin,2,nxt)
			!f(xmax -50+i,j,zmin,2,nxt)=f(i,j,zmin,1,nxt)
			

			c2(i,j,4)=f(xmax -50+i,j,zmin,4,nxt)
			!f(xmax -50+i,j,zmin,4,nxt)=f(i,j,zmin,3,nxt)
			

			c2(i,j,6)=f(xmax -50+i,j,zmin,6,nxt)
			!f(xmax -50+i,j,zmin,6,nxt)=f(i,j,zmin,5,nxt)
			


			
			c2(i,j,1)=f(xmax -50+i,j,zmin,1,nxt)
			!f(xmax -50+i,j,zmin,1,nxt)=f(i,j,zmin,2,nxt)
			

			c2(i,j,3)=f(xmax -50+i,j,zmin,3,nxt)
			!f(xmax -50+i,j,zmin,3,nxt)=f(i,j,zmin,4,nxt)
			

			c2(i,j,5)=f(xmax -50+i,j,zmin,5,nxt)
			f(xmax -50+i,j,zmin,5,nxt)=f(i,j,zmin,6,nxt)
			
		END DO
	END DO

	! B.C. for Zmin 	
	DO i =  xmin, xmin+50
       DO j = ymin, ymax
	   
			!f(i,j,zmin,2,nxt)=c2(i,j,1)
			!f(i,j,zmin,1,nxt)=c2(i,j,2)

            !f(i,j,zmin,4,nxt)=c2(i,j,3)
			!f(i,j,zmin,3,nxt)=c2(i,j,4)

            !f(i,j,zmin,6,nxt)=c2(i,j,5)
			f(i,j,zmin,5,nxt)=c2(i,j,6)
			
			
		END DO
	END DO

	! B.C. for Zmax - 50	
	DO i = xmin +50, xmax -50
       DO j = ymin, ymax
	   
					
			f(i,j,zmax -50,1,nxt)=f(i,j,zmax -50,2,nxt)
			f(i,j,zmax -50,3,nxt)=f(i,j,zmax -50,4,nxt)
			f(i,j,zmax -50,5,nxt)=f(i,j,zmax -50,6,nxt)
			
			f(i,j,zmax -50,2,nxt)=f(i,j,zmax -50,1,nxt)
			f(i,j,zmax -50,4,nxt)=f(i,j,zmax -50,3,nxt)
			f(i,j,zmax -50,6,nxt)=f(i,j,zmax -50,5,nxt)
			
		END DO
	END DO
	
	
! B.C. for Zmax 
    DO i = xmin, xmax
       DO j = ymin, ymax
			
			f(i,j,zmax,2,nxt)=f(i,j,zmax,1,nxt)
			f(i,j,zmax,4,nxt)=f(i,j,zmax,3,nxt)
			f(i,j,zmax,6,nxt)=f(i,j,zmax,5,nxt)
			
			f(i,j,zmax,1,nxt)=f(i,j,zmax,2,nxt)
			f(i,j,zmax,3,nxt)=f(i,j,zmax,4,nxt)
			f(i,j,zmax,5,nxt)=f(i,j,zmax,6,nxt)
			
		END DO
	END DO
 
 RETURN
 END SUBROUTINE Stream
